# CryptoCasino
An secure, easy to use casino with multiple games for crypto currencies
